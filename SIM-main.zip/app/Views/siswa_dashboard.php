<!DOCTYPE html>
<html>
<head>
    <title>Siswa Dashboard</title>
</head>
<body>
    <h2>Siswa Dashboard</h2>
    <ul>
        <li><a href="#">Tugas</a></li>
        <li><a href="#">Nilai Tugas</a></li>
        <li><a href="#">Konsultasi</a></li>
        <li><a href="/logout">Logout</a></li>
    </ul>
</body>
</html>

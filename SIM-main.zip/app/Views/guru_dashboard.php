<!DOCTYPE html>
<html>
<head>
    <title>Guru Dashboard</title>
</head>
<body>
    <h2>Guru Dashboard</h2>
    <ul>
        <li><a href="#">Tambah Tugas</a></li>
        <li><a href="#">Tambah Nilai</a></li>
        <li><a href="#">Baca Konsultasi</a></li>
        <li><a href="/logout">Logout</a></li>
    </ul>
</body>
</html>

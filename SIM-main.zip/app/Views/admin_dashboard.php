<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h2>Admin Dashboard</h2>
    <ul>
        <li><a href="#">Data Nilai</a></li>
        <li><a href="#">Data Siswa</a></li>
        <li><a href="#">Data Guru</a></li>
        <li><a href="#">Data Tugas</a></li>
        <li><a href="/logout">Logout</a></li>
    </ul>
</body>
</html>
